#!/bin/bash
zip -r app.zip *
nw app.zip
